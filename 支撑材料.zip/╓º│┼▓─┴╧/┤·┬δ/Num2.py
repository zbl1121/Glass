# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 17:09:39 2022

@author: 86178
"""


import random
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 计算欧拉距离
def calcDis(dataSet, centroids, k):
    clalist=[]
    for data in dataSet:
        diff = np.tile(data, (k, 1)) - centroids  #相减   (np.tile(a,(2,1))就是把a先沿x轴复制1倍，即没有复制，仍然是 [0,1,2]。 再把结果沿y方向复制2倍得到array([[0,1,2],[0,1,2]]))
        squaredDiff = diff ** 2     #平方
        squaredDist = np.sum(squaredDiff, axis=1)   #和  (axis=1表示行)
        distance = squaredDist ** 0.5  #开根号
        clalist.append(distance) 
    clalist = np.array(clalist)  #返回一个每个点到质点的距离len(dateSet)*k的数组
    return clalist

# 计算质心
def classify(dataSet, centroids, k):
    # 计算样本到质心的距离
    clalist = calcDis(dataSet, centroids, k)
    # 分组并计算新的质心
    minDistIndices = np.argmin(clalist, axis=1)    #axis=1 表示求出每行的最小值的下标
    newCentroids = pd.DataFrame(dataSet).groupby(minDistIndices).mean() #DataFramte(dataSet)对DataSet分组，groupby(min)按照min进行统计分类，mean()对分类结果求均值
    newCentroids = newCentroids.values
 
    # 计算变化量
    changed = newCentroids - centroids
 
    return changed, newCentroids

# 使用k-means分类
def kmeans(dataSet, k):
    # 随机取质心
    centroids = random.sample(dataSet, k)
    
    # 更新质心 直到变化量全为0
    changed, newCentroids = classify(dataSet, centroids, k)
    while np.any(changed != 0):
        changed, newCentroids = classify(dataSet, newCentroids, k)
 
    centroids = sorted(newCentroids.tolist())   #tolist()将矩阵转换成列表 sorted()排序
 
    # 根据质心计算每个集群
    cluster = []
    clalist = calcDis(dataSet, centroids, k) #调用欧拉距离
    minDistIndices = np.argmin(clalist, axis=1)  
    for i in range(k):
        cluster.append([])
    for i, j in enumerate(minDistIndices):   #enymerate()可同时遍历索引和遍历元素
        cluster[j].append(dataSet[i])
        
    return centroids, cluster
from sklearn.metrics import silhouette_score
from sklearn.cluster import KMeans
#手肘法算出k值
def get_silhouette_K(data, range_K):
    K = range(2, range_K)
    Scores = [] 
    for k in K:
        kmeans = KMeans(n_clusters=k)
        kmeans.fit(data)
        Scores.append(silhouette_score(data, kmeans.labels_, metric='euclidean'))
    max_idx = Scores.index(max(Scores))
    best_k = K[max_idx]
    plt.plot(K, Scores, 'bx-')
    plt.xlabel('k')
    plt.ylabel('SSE')
    plt.show()
    return best_k
# 创建数据集
def createDataSet():
    df= pd.read_excel("D:\数模\C题\高钾.xlsx",header=None)
    #df= pd.read_excel("D:\数模\C题\铅钡.xlsx",header=None)
    t=np.array(df)
    Temp_List = t.tolist()
    return Temp_List

if __name__=='__main__': 
    dataset = createDataSet()
    k=get_silhouette_K(dataset,9)   
    centroids, cluster = kmeans(dataset,k)
    print('质心为：%s' % centroids)
    print('集群为：%s' % cluster)
    #结果导出到excel
    '''
    df = pd.DataFrame(centroids)
    df.to_excel("D:\数模\C题\高钾质心.xlsx",sheet_name='高钾质心', index=False)
    df = pd.DataFrame(cluster[0])
    df.to_excel("D:\数模\C题\高钾一类.xlsx",sheet_name='高钾一类', index=False)
    df = pd.DataFrame(cluster[1])
    df.to_excel("D:\数模\C题\高钾二类.xlsx",sheet_name='高钾二类', index=False)
    '''
    '''
    df = pd.DataFrame(centroids)
    df.to_excel("D:\数模\C题\铅钡质心.xlsx",sheet_name='铅钡质心', index=False)
    df = pd.DataFrame(cluster[0])
    df.to_excel("D:\数模\C题\铅钡一类.xlsx",sheet_name='铅钡一类', index=False)
    df = pd.DataFrame(cluster[1])
    df.to_excel("D:\数模\C题\铅钡二类.xlsx",sheet_name='铅钡二类', index=False)
    '''
    
    for i in cluster:
        for j in range(len(i)):
            plt.scatter(i[j][0],i[j][1], marker = 'o',color = 'green', s = 40 ,label = '原始点')
                                                        #  记号形状       颜色      点的大小      设置标签
            for k in range(len(centroids)):
                plt.scatter(centroids[k][0],centroids[k][1],marker='x',color='red',s=50,label='质心')
    plt.show() 