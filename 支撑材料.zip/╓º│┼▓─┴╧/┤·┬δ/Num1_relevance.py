# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import numpy as np
import pandas as pd
from pathlib import Path
from  scipy.stats import chi2_contingency
filename = Path("D:\数模\C题\附件1.xlsx")
# read the file使用哪列：usecols参数从0开始
df= pd.read_excel(filename,sheet_name='表单1')
a=pd.crosstab(df['表面风化'], df['纹饰'])
print(a)
kf_datad = np.array(a)
kf = chi2_contingency(kf_datad)
print('皮尔逊卡方=%.4f, 渐进显著性=%.4f, 自由度=%i expected_frep=%s'%kf)
b=pd.crosstab(df['表面风化'], df['颜色'])
print(b)
kf_datad = np.array(b)
kf = chi2_contingency(kf_datad)
print('皮尔逊卡方=%.4f, 渐进显著性=%.4f, 自由度=%i expected_frep=%s'%kf)
c=pd.crosstab(df['表面风化'], df['类型'])
print(c)
kf_datad = np.array(c)
kf = chi2_contingency(kf_datad)
print('皮尔逊卡方=%.4f, 渐进显著性=%.4f, 自由度=%i expected_frep=%s'%kf)